import yfinance as yf
import pandas as pd
import matplotlib.pyplot as plt
import mplfinance as mpf
from ta.momentum import RSIIndicator
from ta.trend import MACD

def buscar_dados(ticker, inicio, fim):
    dados = yf.download(ticker, start=inicio, end=fim)
    return dados

def calcular_indicadores(dados):
    # Transforma 'Close' em série 1D com float
    close = pd.Series(dados['Close'].values.ravel(), index=dados.index, dtype=float)

    rsi = RSIIndicator(close=close)
    dados['RSI'] = rsi.rsi()

    macd = MACD(close=close)
    dados['MACD'] = macd.macd()
    dados['MACD_SIGNAL'] = macd.macd_signal()

    dados['MM_20'] = close.rolling(window=20).mean()
    dados['MM_50'] = close.rolling(window=50).mean()

    return dados

def gerar_alerta(dados):
    alertas = []

    # RSI
    rsi_atual = dados['RSI'].iloc[-1]
    if rsi_atual < 30:
        alertas.append("🔽 RSI indica *sobrevendido* — possível ponto de compra")
    elif rsi_atual > 70:
        alertas.append("🔼 RSI indica *sobrecomprado* — possível ponto de venda")

    # MACD
    macd_atual = dados['MACD'].iloc[-1]
    macd_signal = dados['MACD_SIGNAL'].iloc[-1]
    if macd_atual > macd_signal:
        alertas.append("📈 MACD indica *momentum de alta*")
    elif macd_atual < macd_signal:
        alertas.append("📉 MACD indica *momentum de baixa*")

    # Médias Móveis (cruzamento)
    mm20_hoje = dados['MM_20'].iloc[-1]
    mm50_hoje = dados['MM_50'].iloc[-1]
    mm20_ontem = dados['MM_20'].iloc[-2]
    mm50_ontem = dados['MM_50'].iloc[-2]

    if mm20_ontem < mm50_ontem and mm20_hoje > mm50_hoje:
        alertas.append("🟢 Cruzamento de Médias: MM20 cruzou acima da MM50 — sinal de COMPRA")
    elif mm20_ontem > mm50_ontem and mm20_hoje < mm50_hoje:
        alertas.append("🔴 Cruzamento de Médias: MM20 cruzou abaixo da MM50 — sinal de VENDA")

    return "\n".join(alertas) if alertas else "🔍 Nenhum sinal forte no momento"

def plotar_grafico(dados, ticker):
    plt.figure(figsize=(14, 10))

    # 1 - Preço + Médias Móveis
    plt.subplot(3, 1, 1)
    plt.plot(dados['Close'], label='Fechamento')
    plt.plot(dados['MM_20'], label='MM 20', linestyle='--')
    plt.plot(dados['MM_50'], label='MM 50', linestyle='--')
    plt.title(f'{ticker} - Preço com Médias Móveis')
    plt.ylabel('Preço (R$)')
    plt.legend()
    plt.grid()

    # 2 - RSI
    plt.subplot(3, 1, 2)
    plt.plot(dados['RSI'], label='RSI', color='purple')
    plt.axhline(70, color='green', linestyle='--', linewidth=1)
    plt.axhline(30, color='red', linestyle='--', linewidth=1)
    plt.title('Índice de Força Relativa (RSI)')
    plt.ylabel('RSI')
    plt.legend()
    plt.grid()

    # 3 - MACD
    plt.subplot(3, 1, 3)
    plt.plot(dados['MACD'], label='MACD', color='blue')
    plt.plot(dados['MACD_SIGNAL'], label='Sinal', color='orange')
    plt.title('MACD')
    plt.ylabel('Valor')
    plt.legend()
    plt.grid()

    plt.tight_layout()

    # 📸 Salvar o gráfico como imagem
    nome_arquivo = f"grafico_{ticker}.png"
    plt.savefig(nome_arquivo, dpi=300)
    print(f"\n📁 Gráfico salvo como: {nome_arquivo}")

    plt.show()

def plotar_candlestick(dados, ticker):
    # Colunas essenciais para o gráfico
    colunas = ['Open', 'High', 'Low', 'Close', 'Volume']

    # Remove colunas duplicadas e copia os dados
    dados = dados.loc[:, ~dados.columns.duplicated()].copy()

    # Cria novo DataFrame com colunas convertidas corretamente
    dados_candle = pd.DataFrame(index=dados.index)
    
    for coluna in colunas:
        if coluna in dados.columns:
            coluna_serie = dados[coluna]
            if isinstance(coluna_serie, pd.Series):
                dados_candle[coluna] = pd.to_numeric(coluna_serie, errors='coerce')
            else:
                dados_candle[coluna] = pd.to_numeric(coluna_serie.iloc[:, 0], errors='coerce')
        else:
            print(f"❌ Coluna '{coluna}' não encontrada nos dados.")
            return

    # Remove linhas com dados inválidos
    dados_candle.dropna(inplace=True)

    # Garante que o índice é datetime
    if not pd.api.types.is_datetime64_any_dtype(dados_candle.index):
        dados_candle.index = pd.to_datetime(dados_candle.index, errors='coerce')

    # Nome do índice
    dados_candle.index.name = 'Date'

    # Ordena por data
    dados_candle.sort_index(inplace=True)

    # Gera gráfico candlestick
    mpf.plot(
        dados_candle,
        type='candle',
        style='yahoo',
        volume=True,
        title=f'{ticker} - Candlestick com Volume',
        mav=(20, 50),
        ylabel='Preço (R$)',
        ylabel_lower='Volume',
        tight_layout=True
    )

# Execução principal
ticker = input("Digite o código do ativo (ex: PETR4.SA): ").upper()
dados = buscar_dados(ticker, '2024-01-01', '2025-01-01')
dados = calcular_indicadores(dados)

alerta = gerar_alerta(dados)
print(f"\n📊 Alerta de Análise Técnica para {ticker}:\n{alerta}")

plotar_candlestick(dados, ticker)

plotar_grafico(dados, ticker)
